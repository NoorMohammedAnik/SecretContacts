<?php
 define('HOST','localhost');         //hostname
 define('USER','cseiiucc_anik');     //username
 define('PASS','noor786786');        //user password
 define('DB','cseiiucc_contacts');  //dtabase name
 
 $con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');

?>